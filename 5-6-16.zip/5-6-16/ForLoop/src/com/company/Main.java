package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        for(int i=0 ; i<10 ; i++){
            System.out.println("i value : "+i);
        }
    }
}
