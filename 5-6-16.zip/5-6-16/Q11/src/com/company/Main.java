package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int var1 = 5;
        int var2 = 6;

        if(var1 == 5) {

            System.out.println("Today is 5th June and Sunday");

        }
         if(var2 == 6){

             System.out.println("Tomorrow will be 6th June and Monday");
        }
    }
}
