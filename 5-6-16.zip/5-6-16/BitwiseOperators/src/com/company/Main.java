package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int num1 = 42;
        int num2 = 15;
        System.out.println("And Result : "+(num1&num2));
        System.out.println("OR Result : "+(num1|num2));
        System.out.println("XOR Result : "+(num1^num2));


    }
}
