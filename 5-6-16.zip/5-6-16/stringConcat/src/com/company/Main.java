package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String string1 = "My Name is : ";
        String string2 = "Ibad Qureshi";
        String string3 = "I am in Graduation:";
        String string4= "6th Semester";
        String string5 = "I have done Inter in year: ";
        String string6 = "2103";

        String concat1 = string1+string2;
        System.out.println(concat1);

        String concat2 = string3+string4;
        System.out.println(concat2);

        String concat3 = string5+string6;
        System.out.println(concat3);

    }
}
