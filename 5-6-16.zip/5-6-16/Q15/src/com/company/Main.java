package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int i;
        int j;

        for (i=1 ; i<=101 ; i++){

            if(i%2 == 0){
                System.out.print(i);
            }
            System.out.println();



        }
    }
}
