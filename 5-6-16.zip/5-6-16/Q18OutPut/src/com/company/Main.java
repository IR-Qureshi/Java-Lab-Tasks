package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int number =4;
        double alpha = -1.0;
        if(number> 0){
            if(alpha>0){
                System.out.println("Here I am!");
            }
            else{
                System.out.println("No I'am here!");
            }
                System.out.println("No, actually, I'am here!");
        }
    }
}
