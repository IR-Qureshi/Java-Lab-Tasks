package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int i;
        for(i=1;i<=10;i++){
            System.out.println("3 * " + i + " = "+ (3*i));
        }
    }
}
