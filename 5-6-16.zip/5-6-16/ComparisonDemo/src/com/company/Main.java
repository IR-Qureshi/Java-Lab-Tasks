package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int var1 =1;
        int var2 =2;
        if(var1 != var2){
            System.out.println("var1 != var2");
        }
        if(var1 > var2){
            System.out.println("var1 > var2");
        }
        if(var1 < var2 ){
            System.out.println("var1 < var2");
        }
        if(var1 == var2){
            System.out.println("var1 == var2");
        }
        if(var1 >= var2){
            System.out.println("var1 >= var2");
        }
        if(var1 <= var2){
            System.out.println("var1 <= var2");
        }
    }
}
