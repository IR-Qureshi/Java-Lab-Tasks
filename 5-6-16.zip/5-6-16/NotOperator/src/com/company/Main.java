package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        boolean var1 = true;
        boolean var2 = false;

        var1= false;

        if(!var1){
           System.out.println("if block execute");
        }
        else{
            System.out.println("else block execute");
        }
    }
}
