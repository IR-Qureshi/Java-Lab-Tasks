package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Boolean var1 = true;
        Boolean var2 = false;
        if(var1){
            System.out.println("if block execute");
        }
        else{
            System.out.println("else block execute");
        }


    }
}
