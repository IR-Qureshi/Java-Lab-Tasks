package com.company;
import java.util.*;
import java.lang.Math;

class deci {

    int convert(int n) {
        int tem=1,power=0;
        int decimal=0;
        for (int j=0;j<n;j++) {
            if(n==0) {
                break;
            } else {
                while(n>0) {
                    tem=n%10;
                    n=n/10;
                    decimal+=(tem*(Math.pow(2,power)));

                    power++;
                }
            }
        }
        return decimal;
    }

    }


public class Main {

    public static void main(String args[]) {
        System.out.print("enter the binary no");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        deci dc=new deci();
        int i=dc.convert(n);
        System.out.print(i);


    }
}
