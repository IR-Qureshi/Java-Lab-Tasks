package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int i;
        int j;
        int k;
        int l;
        int m;
        int n;

        for(i=1;i<5;i++) {
            for(m=i+5; m<=1; m++) {
             System.out.print(" ");
            }
        for(j=1; j<=i; j++) {
            System.out.print("*");
        }
          System.out.println();
        }
        for (k = 4; k>0 ; k--) {
            for (l = 5; l<=k+4; l++) {

                System.out.print("*");
            }
            System.out.println();
        }


        }
}
