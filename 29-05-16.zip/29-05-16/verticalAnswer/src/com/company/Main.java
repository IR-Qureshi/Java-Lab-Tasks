package com.company;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        int i;
        int j;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a nos from 0-99:");
        i= input.nextInt();

        System.out.println(i/10);
        System.out.println(i%10);

    }
}
