package com.company;

public class Main {

    public static void main(String[] args) {

        int i;


        for(i=1; i<=100; i++) {
            System.out.print(i);

            if(i%3 == 0 ){
                System.out.print("\t 4");
            }
            if(i% 4 == 0){
                System.out.print("\t 4/");
            }
            System.out.println();



        }



    }
}
