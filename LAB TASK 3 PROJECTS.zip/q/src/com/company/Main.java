package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Scanner s = new Scanner(System.in);

        Teacher t = new Teacher();

        Student obj = new Student();

        String i;
        String n;
        String q;
        String c;
        String sa;
        String cou;

        int b;
        int tch=0;
        int std=0;
        int no=0;
        int no1=0;

        do

        {


            System.out.println("------------------------------------------------------------------------------------");

            System.out.println();

            System.out.println("\tWELCOME TO UNIVERSITY MANAGEMENT SYSTEM !!!");

            System.out.println("Press 1 For Teacher");

            System.out.println("Press 2 For Student");

            System.out.println("Press 3 For Exit");

            System.out.println();

            b = s.nextInt();


            switch (b) {
                case 1:

                    do

                    {

                        System.out.println("------------------------------------------------------------------------------------");

                        System.out.println();

                        System.out.println("\tTeacher !!!");

                        System.out.println("Press 1 To Insert A Teacher");

                        System.out.println("Press 2 To View All Teacher");

                        System.out.println("Press 3 To Delete A Teacher");

                        System.out.println("Press 4 To Update A Teacher");

                        System.out.println("Press 5 For Exit");

                        System.out.println();

                        tch = s.nextInt();


                        switch (tch) {
                            case 1:
                                System.out.println("Enter Id Of Teacher : ");

                                i = s.next();

                                System.out.println("Enter Name Of Teacher : ");

                                n = s.next();

                                System.out.println("Enter Qualification Of Teacher : ");

                                q = s.next();

                                System.out.println("Enter Contact Number Of Teacher : ");

                                c = s.next();

                                System.out.println("Enter Salary Of Teacher : ");

                                sa = s.next();


                                t.Insert(i, n, q, c, sa, no);

                                no++;

                                break;

                            case 2:

                                t.View(no);

                                break;

                            case 3:

                                System.out.println("Enter The ID Of Teacher Which You Want to Delete : ");
                                String idd = s.next();

                                t.Delete(idd,no);


                                break;

                            case 4:

                                System.out.println("Enter The ID Of Teacher Which You Want to Update : ");
                                String tid = s.next();

                                int result = t.updatecheck(tid,no);

                                if (result == -1)
                                {
                                    System.out.println("YOU HAVE INPUT AN INVALID ID !!!!");

                                }
                                else
                                {
                                    System.out.println("Which Field Do You Want To Update ?");

                                    System.out.println("Press 1 For Name Of Teacher : ");
                                    System.out.println("Press 2 For Qualification Of Teacher : ");
                                    System.out.println("Press 3 For Contact Number Of Teacher : ");
                                    System.out.println("Press 4 For Salary Of Teacher : ");

                                    String u_data=" ";

                                    int decide = s.nextInt();


                                    switch (decide) {

                                        case 1:
                                            System.out.println("Enter Name Of Teacher : ");
                                            u_data = s.next();
                                            break;

                                        case 2:
                                            System.out.println("Enter Qualification Of Teacher : ");
                                            u_data = s.next();
                                            break;

                                        case 3:
                                            System.out.println("Enter Contact Number Of Teacher : ");
                                            u_data = s.next();
                                            break;

                                        case 4:
                                            System.out.println("Enter Salary Of Teacher : ");
                                            u_data = s.next();
                                            break;

                                        default:
                                            System.out.println("Invalid Input !");
                                            break;
                                    }

                                    t.update(u_data,result,decide);

                                    System.out.println();
                                    System.out.println("Updated");


                                    }


                                break;

                            case 5:

                                break;

                            default:

                                System.out.println("Invalid Input ! ");
                                break;

                        }
                        }
                        while (tch != 3) ;



                    break;


                case 2:

                    do

                    {

                        System.out.println("------------------------------------------------------------------------------------");

                        System.out.println();

                        System.out.println("\tStudents !!!");

                        System.out.println("Press 1 To Insert A Student");

                        System.out.println("Press 2 To View All Students");

                        System.out.println("Press 3 To Delete A Student");

                        System.out.println("Press 4 To Update A Student");

                        System.out.println("Press 5 For Exit");


                        System.out.println();

                        std = s.nextInt();


                        switch (std) {
                            case 1:
                                System.out.println("Enter Roll# of Student : ");

                                i = s.next();

                                System.out.println("Enter Name Of Student : ");

                                n = s.next();

                                System.out.println("Enter Semester of Student : ");

                                q = s.next();

                                System.out.println("Enter Section of Student : ");

                                c = s.next();

                                System.out.println("Enter Batch of Student : ");

                                sa = s.next();

                                System.out.println("Enter Course Name of Student: ");

                                cou = s.next();

                                obj.Inserts(i, n, q, c, sa,cou, no1);

                                no1++;

                                break;


                            case 2:

                                obj.Views(no1);

                                break;

                            case 3:

                                System.out.println("Enter The ID Of Student Which You Want to Delete : ");
                                String idd = s.next();

                                obj.Delete(idd,no);

                                break;

                            case 4:


                                System.out.println("Enter The ID Of Student Which You Want to Update : ");
                                String tid = s.next();

                                int result = obj.updatecheck(tid,no);

                                if (result == -1)
                                {
                                    System.out.println("YOU HAVE INPUT AN INVALID ID !!!!");

                                }
                                else
                                {
                                    System.out.println("Which Field Do You Want To Update ?");

                                    System.out.println("Press 1 For Name Of Student");
                                    System.out.println("Press 2 For Semester Of Student");
                                    System.out.println("Press 3 For Section Of Student");
                                    System.out.println("Press 4 For Batch Of Student ");
                                    System.out.println("Press 5 For Course Of Stedent");

                                    String u_data=" ";

                                    int decide = s.nextInt();


                                    switch (decide) {

                                        case 1:
                                            System.out.println("Enter Name Of Student : ");
                                            u_data = s.next();
                                            break;

                                        case 2:
                                            System.out.println("Enter Semester Of Student : ");
                                            u_data = s.next();
                                            break;

                                        case 3:
                                            System.out.println("Enter Section Of Student : ");
                                            u_data = s.next();
                                            break;

                                        case 4:
                                            System.out.println("Enter Batch Of Student : ");
                                            u_data = s.next();
                                            break;

                                        case 5:
                                            System.out.println("Enter Course Of Student : ");
                                            u_data = s.next();
                                            break;

                                        default:
                                            System.out.println("Invalid Input !");
                                            break;
                                    }

                                    t.update(u_data,result,decide);

                                    System.out.println();
                                    System.out.println("Updated");


                                }

                                break;

                            case 5:

                                break;


                            default:

                                System.out.println("Invalid Input ! ");
                                break;

                        }
                    }
                    while (std != 3) ;



                    break;


                        case  3:


                            break;

                default:

                    System.out.println("Invalid Input ! ");
                    break;


            }
        }while (b!=3);
    }
}
