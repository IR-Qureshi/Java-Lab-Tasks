package com.company;

/**
 * Created by Champ on 6/18/2016.
 */
public class University {
}
