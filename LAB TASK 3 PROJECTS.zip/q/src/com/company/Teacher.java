package com.company;

import com.sun.java_cup.internal.runtime.Scanner;

/**
 * Created by Champ on 6/18/2016.
 */


    public class Teacher {



        public String data[][] = new String[100][5];

    public void Insert(String Id,String name, String qualification,String contact,String salary,int number ){



       data[number] = new String[5];

        data[number][0] = Id;
        data[number][1] = name;
        data[number][2] = qualification;
        data[number][3] = contact;
        data[number][4] = salary;


    }


        public void View(int n){

            System.out.println("------------------------------------------------------------------------------------");


            int i;
            for(i=0;i<n ;i++)
            {

                if(data[i][0]=="0"&&data[i][1]=="0"&&data[i][2]=="0"&&data[i][3]=="0"&&data[i][4]=="0")
                {

                    i++;
                }

                else
                {
                System.out.println("________________________________________");
                System.out.println("ID               :\t\t\t" + data[i][0]);
                System.out.println("NAME             :\t\t\t" + data[i][1]);
                System.out.println("Qualification    :\t\t\t" + data[i][2]);
                System.out.println("Contact #        :\t\t\t" + data[i][3]);
                System.out.println("SALARY           :\t\t\t" + data[i][4]);
                System.out.println("'''''''''''''''''''''''''''''''''''''''''");
            }


                System.out.println();
            }


        }

    public void Delete(String id,int no)
    {
        int i=0,i1=0;
        int count=0;

        for(i=0;i<no;i++)
        {
            if(data[i][0].equals(id))
            {
                count++;
                i1 = 1;

            }

            else
            {

                continue;

            }

        }

        if(count>0)
        {
            for(int j=0 ; j<5; j++)
            {
                data[i1][j]= "0" ;

            }

        }

        else
        {

            System.out.println("YOU HAVE INPUT AN INVALID ID !!!!");


        }


    }


    public int updatecheck(String id,int number)
    {
        int count=0;
        int i1 =0;

        for(int i = 0 ; i < number ; i++)
        {
            if(data[i][0].equals(id))
            {
                count++;
                i1 = i;

            }

            else
            {

                continue;

            }

        }

        if(count>0)
        {
            return i1;
        }

        else
        {

            return -1;

        }

    }

    public void update(String value,int identity,int index)
    {
        data[identity][index] = value;

    }



    }
