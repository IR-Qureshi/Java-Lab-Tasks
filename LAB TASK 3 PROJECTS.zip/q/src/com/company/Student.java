package com.company;

/**
 * Created by Champ on 6/19/2016.
 */
public class Student {
        public String datas[][] = new String[100][6];

        public void Inserts(String roll,String name, String semester,String section,String batch,String course,int number ){


            datas[number] = new String[6];

            datas[number][0] = roll;
            datas[number][1] = name;
            datas[number][2] = semester;
            datas[number][3] = section;
            datas[number][4] = batch;
            datas[number][5] = course;


        }


        public void Views(int n){
            int i;
            System.out.println("------------------------------------------------------------------------------------");

            for(i=0;i<n ;i++)
            {
                if(datas[i][0]=="0"&&datas[i][1]=="0"&&datas[i][2]=="0"&&datas[i][3]=="0"&&datas[i][4]=="0"&&datas[i][5]=="0")
                {

                    i++;
                }

                else {


                    System.out.println("________________________________________");
                    System.out.println("Roll #     :\t\t\t" + datas[i][0]);
                    System.out.println("NAME       :\t\t\t" + datas[i][1]);
                    System.out.println("Semester   :\t\t\t" + datas[i][2]);
                    System.out.println("Section    :\t\t\t" + datas[i][3]);
                    System.out.println("Batch      :\t\t\t" + datas[i][4]);
                    System.out.println("Course     :\t\t\t" + datas[i][5]);
                    System.out.println("'''''''''''''''''''''''''''''''''''''''''");

                }

                System.out.println();
            }


        }


    public void Delete(String id,int no)
    {
        int i=0,i1=0;
        int count=0;

        for(i=0;i<no;i++)
        {
            if(datas[i][0].equals(id))
            {
                count++;
                i1 = 1;

            }

            else
            {

                continue;

            }

        }

        if(count>0)
        {
            for(int j=0 ; j<6; j++)
            {
                datas[i1][j]= "0" ;

            }

        }

        else
        {

            System.out.println("YOU HAVE INPUT AN INVALID ID !!!!");


        }


    }


    public int updatecheck(String id,int number)
    {
        int count=0;
        int i1 =0;

        for(int i = 0 ; i < number ; i++)
        {
            if(datas[i][0].equals(id))
            {
                count++;
                i1 = i;

            }

            else
            {

                continue;

            }

        }

        if(count>0)
        {
            return i1;
        }

        else
        {

            return -1;

        }

    }

    public void update(String value,int identity,int index)
    {
        datas[identity][index] = value;

    }





}
